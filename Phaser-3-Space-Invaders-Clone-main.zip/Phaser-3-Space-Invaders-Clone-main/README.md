# Phaser 3 Space Invaders
My goal was to create a space invaders replica to show on my youtube channel [Vbs Office](https://www.youtube.com/channel/UC4pI_JCFjMjFulytCZE0DCQ). It turned out pretty good so, I put it on github.

## Running the game
I used an extension called [Live Server](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer) in VS code to run the development server necasary to run the game. You could also use an online IDE like [Repl](https://replit.com).

## Live Demo
You can play the finished game [here](https://Space-Invaders.throb.repl.co).

## Libraries
* Phaser - [Website](http://phaser.io)
* HowlerJS - [Website](https://howlerjs.com/)